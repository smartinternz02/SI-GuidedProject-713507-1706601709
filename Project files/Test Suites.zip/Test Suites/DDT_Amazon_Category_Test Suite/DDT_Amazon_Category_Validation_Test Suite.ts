<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>DDT_Amazon_Category_Validation_Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>c424625c-0e34-4726-8abd-9a01977a8454</testSuiteGuid>
   <testCaseLink>
      <guid>6025de4a-f9d9-4e11-bc37-f577e71f783c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Data_Driven_Testing/TC_Amazon_Validating_Category_Excel_001</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>80713918-542b-477a-8f93-e4cc35669aa4</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/DDT_Test Data/Amazon_Test Data_Excel_Category</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>80713918-542b-477a-8f93-e4cc35669aa4</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>category</value>
         <variableId>c42a364d-5bd1-4fb4-b469-5ebb6268049a</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>80713918-542b-477a-8f93-e4cc35669aa4</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Item</value>
         <variableId>32fd78f5-e00f-4d81-9f28-71d032703f6f</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
