<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_All Categories        Alexa Skills  _59be89</name>
   <tag></tag>
   <elementGuidId>7399ba44-384b-49d3-b304-96ed39dbd20e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>d9ef7e07-9fff-4123-b851-781f4599b7b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>88c2dc15-fdb7-4ed0-a97d-b94a40e2290b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>07ff3e4b-a67a-4907-a865-214ee2139db3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>tMtXT79+70L/E2safYLVSgvzHcs=</value>
      <webElementGuid>144cf363-89b0-47e5-906f-67c171b07654</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>d283cc3f-54f2-4e57-bfe3-e9ef83d267f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>920d108c-1f18-4e7f-8c1b-7263d0c21a21</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>a08645ea-ffa4-49e3-8ec6-6c9186a7a648</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>8c2ee9ed-1645-420b-a9ec-802134d24439</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>8a2b6a71-488a-4390-9ea3-80a7eba899e5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Deals
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    </value>
      <webElementGuid>4d5dd21a-52d3-4be8-a19a-0cab1681ed9c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>431c1242-67c2-4d83-a024-503133192d8e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>884dcca2-7068-46a6-90d3-6cc554407055</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>d8704256-94cb-4fe6-ad6d-45cc52afcded</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>24829918-ff8e-468b-83e8-6e4a505a5243</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = '
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Deals
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    ' or . = '
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Deals
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    ')]</value>
      <webElementGuid>95e8e484-02e4-4a3c-b02f-69be5c9a9f8f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
