
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject



def static "com.qa.test.customFunctions.printHello"() {
    (new com.qa.test.customFunctions()).printHello()
}


def static "com.qa.test.customFunctions.printName"(
    	String name	) {
    (new com.qa.test.customFunctions()).printName(
        	name)
}


def static "com.qa.test.customFunctions.CheckDropDownListElementExist"(
    	TestObject object	
     , 	String option	) {
    (new com.qa.test.customFunctions()).CheckDropDownListElementExist(
        	object
         , 	option)
}
